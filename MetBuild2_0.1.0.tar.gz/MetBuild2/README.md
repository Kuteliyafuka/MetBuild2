# MetBuild2

how to simply  build a model to predict age by DNA methylation



details are waiting for update